import { UserState } from 'app/types';

export const getTimeZone = (state: UserState) => state.timeZone;
