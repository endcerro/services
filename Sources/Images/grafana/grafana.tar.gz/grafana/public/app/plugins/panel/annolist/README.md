# Annotation List Panel -  Native Plugin

This Annotations List panel is **included** with Grafana.

