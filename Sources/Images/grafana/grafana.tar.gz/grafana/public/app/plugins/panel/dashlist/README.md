# Dashlist Panel -  Native Plugin

This Dashlist panel is **included** with Grafana.

The dashboard list panel allows you to display dynamic links to other dashboards. The list can be configured to use starred dashboards, a search query and/or dashboard tags.

Read more about it here:

[https://grafana.com/docs/grafana/latest/features/panels/dashlist/](https://grafana.com/docs/grafana/latest/features/panels/dashlist/)
