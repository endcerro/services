export const DEFAULT_FEED_URL = 'https://grafana.com/blog/news.xml';
export const PROXY_PREFIX = 'https://cors-anywhere.herokuapp.com/';
