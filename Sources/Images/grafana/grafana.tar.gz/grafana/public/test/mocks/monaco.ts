export const monaco = 'monaco';
