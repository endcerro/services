# Heatmap Panel -  Native Plugin

The Heatmap panel allows you to view histograms over time and is **included** with Grafana.

Read more about it here:

[http://docs.grafana.org/features/panels/heatmap/](http://docs.grafana.org/features/panels/heatmap/)
